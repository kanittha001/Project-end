-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 09 เม.ย. 2020 เมื่อ 03:04 AM
-- เวอร์ชันของเซิร์ฟเวอร์: 10.4.11-MariaDB
-- PHP Version: 7.2.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rern`
--

-- --------------------------------------------------------

--
-- โครงสร้างตาราง `author`
--

CREATE TABLE `author` (
  `aut_id` varchar(10) COLLATE utf8_unicode_ci NOT NULL COMMENT 'รหัสเจ้าหน้าที',
  `aut_user` varchar(20) COLLATE utf8_unicode_ci NOT NULL COMMENT 'ชื่อผู้ใช้',
  `aut_pass` varchar(20) COLLATE utf8_unicode_ci NOT NULL COMMENT 'รหัสผ่าน',
  `aut_idcard` varchar(13) COLLATE utf8_unicode_ci NOT NULL COMMENT 'เลขบัตรประจำตัวประชาชน',
  `aut_title` varchar(10) COLLATE utf8_unicode_ci NOT NULL COMMENT 'คำนำหน้า',
  `aut_name` varchar(30) COLLATE utf8_unicode_ci NOT NULL COMMENT 'ชื่อ',
  `aut_lname` varchar(30) COLLATE utf8_unicode_ci NOT NULL COMMENT 'นามสกล',
  `aut_phone` varchar(10) COLLATE utf8_unicode_ci NOT NULL COMMENT 'เบอร์โทรศัพท์',
  `aut_bitthday` date NOT NULL COMMENT 'วันเกิด',
  `aut_address` varchar(100) COLLATE utf8_unicode_ci NOT NULL COMMENT 'ที่อยู่'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- dump ตาราง `author`
--

INSERT INTO `author` (`aut_id`, `aut_user`, `aut_pass`, `aut_idcard`, `aut_title`, `aut_name`, `aut_lname`, `aut_phone`, `aut_bitthday`, `aut_address`) VALUES
('1001', 'khwan_s', '12345', '1909802255734', 'นาง', 'ขวัญฤทัย', 'สามัคคีธรรม', '0993658970', '1975-03-09', '165 ม.3 หมู่บ้านอุดมสุข ต.เขารูปช้าง อ.เมือง จ.สงขลา');

-- --------------------------------------------------------

--
-- โครงสร้างตาราง `import`
--

CREATE TABLE `import` (
  `imp_id` varchar(10) COLLATE utf8_unicode_ci NOT NULL COMMENT 'รหัสสินค้าเข้า',
  `imp_name` varchar(20) COLLATE utf8_unicode_ci NOT NULL COMMENT 'ชื่อสินค้าเข้า',
  `vl_id` varchar(10) COLLATE utf8_unicode_ci NOT NULL COMMENT 'รหัสกลุ่มหมู่บ้าน',
  `aut_id` varchar(10) COLLATE utf8_unicode_ci NOT NULL COMMENT 'รหัสเจ้าหน้าที่'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- dump ตาราง `import`
--

INSERT INTO `import` (`imp_id`, `imp_name`, `vl_id`, `aut_id`) VALUES
('2221', 'ผ้าทอตากใบ', '1111', '1001'),
('2222', 'ผ้าทอเกาะยอ', '1112', '1001');

-- --------------------------------------------------------

--
-- โครงสร้างตาราง `member`
--

CREATE TABLE `member` (
  `mem_id` varchar(10) COLLATE utf8_unicode_ci NOT NULL COMMENT 'รหัสสมาชิก',
  `mem_user` varchar(20) COLLATE utf8_unicode_ci NOT NULL COMMENT 'ชื่อผู้ใช้',
  `mem_pass` varchar(20) COLLATE utf8_unicode_ci NOT NULL COMMENT 'รหัสผ่าน',
  `mem_idcard` varchar(13) COLLATE utf8_unicode_ci NOT NULL COMMENT 'เลขบัตรประจำตัวประชาชน',
  `mem_title` varchar(10) COLLATE utf8_unicode_ci NOT NULL COMMENT 'คำนำหน้า',
  `mem_name` varchar(30) COLLATE utf8_unicode_ci NOT NULL COMMENT 'ชื่อ',
  `mem_lname` varchar(30) COLLATE utf8_unicode_ci NOT NULL COMMENT 'นามสกล',
  `aut_phone` varchar(10) COLLATE utf8_unicode_ci NOT NULL COMMENT 'เบอร์โทรศัพท์',
  `mem_birthdate` date NOT NULL COMMENT 'วันเกิด',
  `mem_address` varchar(100) COLLATE utf8_unicode_ci NOT NULL COMMENT 'ที่อยู่',
  `aut_id` varchar(10) COLLATE utf8_unicode_ci NOT NULL COMMENT 'รหัสเจ้าหน้าที่'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- dump ตาราง `member`
--

INSERT INTO `member` (`mem_id`, `mem_user`, `mem_pass`, `mem_idcard`, `mem_title`, `mem_name`, `mem_lname`, `aut_phone`, `mem_birthdate`, `mem_address`, `aut_id`) VALUES
('0001', 'sandee', '123456', '3909802255738', 'นางสาว', 'แสนดี', 'วงค์ตระกูล', '0879687418', '1998-08-30', '162 ม.5 หมู่บ้านเจริญสุข ค.หาดใหญ่ อ.หาดใหญ่ จ.สงขลา', '1001'),
('0002', 'kakao', '0123456', '5909802255736', 'นางสาว', 'เพียงดาว', 'แจ่มใส', '0900739084', '1998-03-01', '193 ม.4 หมู่บ้านเออบาน่า ต.ควนลัง อ.หาดใหญ่ จ.สงขลา', '1001'),
('0003', 'nongnoo', '987654', '5909802255736', 'นางสาว', 'หนูขวัญ', 'สุขสว่าง', '0901238457', '1998-04-02', '175 ม.3 หมู่บ้านปาล์มสปริง ต.ควนลัง อ.หาดใหญ่ จ.สงขลา', '1001');

-- --------------------------------------------------------

--
-- โครงสร้างตาราง `orderr`
--

CREATE TABLE `orderr` (
  `ord_id` varchar(10) COLLATE utf8_unicode_ci NOT NULL COMMENT 'รหัสการสั่งซื้อ',
  `typ_id` varchar(10) COLLATE utf8_unicode_ci NOT NULL COMMENT 'รหัสประเภทสินค้า',
  `mem_id` varchar(10) COLLATE utf8_unicode_ci NOT NULL COMMENT 'รหัสสมาชิก',
  `aut_id` varchar(10) COLLATE utf8_unicode_ci NOT NULL COMMENT 'รหัสเจ้าหน้าที่',
  `amount_money` float NOT NULL COMMENT 'จำนวนเงิน',
  `pr_status` varchar(10) COLLATE utf8_unicode_ci NOT NULL COMMENT 'สถานะการชำระเงิน',
  `w_date` varchar(20) COLLATE utf8_unicode_ci NOT NULL COMMENT 'วันที่ชำระเงิน',
  `w_time` time NOT NULL COMMENT 'เวลาที่ชำระเงิน'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- dump ตาราง `orderr`
--

INSERT INTO `orderr` (`ord_id`, `typ_id`, `mem_id`, `aut_id`, `amount_money`, `pr_status`, `w_date`, `w_time`) VALUES
('4331', '7111', '0001', '1001', 199, 'รอชำระเงิน', '2019-12-22', '12:30:00');

-- --------------------------------------------------------

--
-- โครงสร้างตาราง `stock`
--

CREATE TABLE `stock` (
  `st_id` varchar(10) COLLATE utf8_unicode_ci NOT NULL COMMENT 'รหัสสต็อกสินค้า',
  `type_id` varchar(10) COLLATE utf8_unicode_ci NOT NULL COMMENT 'รหัสประเภทสินค้า',
  `vl_id` varchar(10) COLLATE utf8_unicode_ci NOT NULL COMMENT 'รหัสกลุ่มหมู่บ้าน',
  `aut_id` varchar(10) COLLATE utf8_unicode_ci NOT NULL COMMENT 'รหัสเจ้าหน้าที่'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- dump ตาราง `stock`
--

INSERT INTO `stock` (`st_id`, `type_id`, `vl_id`, `aut_id`) VALUES
('5531', '7111', '1111', '1001');

-- --------------------------------------------------------

--
-- โครงสร้างตาราง `type`
--

CREATE TABLE `type` (
  `typ_id` varchar(10) COLLATE utf8_unicode_ci NOT NULL COMMENT 'รหัสประเภทสินค้า',
  `type_name` varchar(20) COLLATE utf8_unicode_ci NOT NULL COMMENT 'ชื่อประเภทสินค้า',
  `typ_price` int(4) NOT NULL COMMENT 'ราคา',
  `aut_id` varchar(10) COLLATE utf8_unicode_ci NOT NULL COMMENT 'รหัสเจ้าหน้าที่'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- dump ตาราง `type`
--

INSERT INTO `type` (`typ_id`, `type_name`, `typ_price`, `aut_id`) VALUES
('7111', 'ผ้าชิ้น', 199, '1001'),
('7112', 'ผ้าพิมพ์', 250, '1001'),
('7113', 'ผ้าบาติกเขียน', 550, '1001');

-- --------------------------------------------------------

--
-- โครงสร้างตาราง `village`
--

CREATE TABLE `village` (
  `vl_id` varchar(10) COLLATE utf8_unicode_ci NOT NULL COMMENT 'รหัสกลุ่มหมู่บ้าน',
  `vl_name` varchar(20) COLLATE utf8_unicode_ci NOT NULL COMMENT 'ชื่อกล่มหมู่บ้าน',
  `vl_address` varchar(100) COLLATE utf8_unicode_ci NOT NULL COMMENT 'ที่อยู่',
  `aut_id` varchar(10) COLLATE utf8_unicode_ci NOT NULL COMMENT 'รหัสเจ้าหน้าที่'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- dump ตาราง `village`
--

INSERT INTO `village` (`vl_id`, `vl_name`, `vl_address`, `aut_id`) VALUES
('1111', 'สงขลาบาติก', '292 ต.บ่อยาง อ.เมือง จ.สงขลา', '1001'),
('1112', 'โกบาติก', '106 ม.7 ต.คูขุด อ.สทิงพระ จ.สงขลา', '1001'),
('1113', 'หนึ่งบาติกสตูล', '22 ม.3 ต.ทุ่งหว้า อ.ทุ่งหว้า จ.สตูล', '1001'),
('1114', 'ผ้าทอตากใบ', '190/2 ม.2 อ.ตากใบ จ.นราธิวาส', '1001'),
('1115', 'ผ้าทอเกาะยอ', '53/1 ม.2 ต.เกาะยอ อ.เมือง จ.สงขลา', '1001');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `author`
--
ALTER TABLE `author`
  ADD PRIMARY KEY (`aut_id`);

--
-- Indexes for table `import`
--
ALTER TABLE `import`
  ADD PRIMARY KEY (`imp_id`);

--
-- Indexes for table `member`
--
ALTER TABLE `member`
  ADD PRIMARY KEY (`mem_id`);

--
-- Indexes for table `orderr`
--
ALTER TABLE `orderr`
  ADD PRIMARY KEY (`ord_id`);

--
-- Indexes for table `stock`
--
ALTER TABLE `stock`
  ADD PRIMARY KEY (`st_id`);

--
-- Indexes for table `type`
--
ALTER TABLE `type`
  ADD PRIMARY KEY (`typ_id`);

--
-- Indexes for table `village`
--
ALTER TABLE `village`
  ADD PRIMARY KEY (`vl_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
