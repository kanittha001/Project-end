<?php

$dbc = mysqli_connect("localhost","root","","buysell");
$dbc -> set_charset("utf8");

?>