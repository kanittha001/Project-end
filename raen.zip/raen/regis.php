<!DOCTYPE html>
<?php



?>
<html lang="en">
<head>
	<title> สมัครสมาชิก </title>
	<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <link href="//netdna.bootstrapcdn.com/bootstrap/3.1.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"> <!--ไอคอน-->
    <script src="//netdna.bootstrapcdn.com/bootstrap/3.1.0/js/bootstrap.min.js"></script>
    <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>

     <!--ลิงค์ที่มา navbar ส่วนบน-->
     <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <style>
    
    .navbar {
      margin-bottom: 50px;
      border-radius: 0;
    }
    
    
    .jumbotron {
      background-image: url("ba.jpg");
      color: white;
      font-family: "Lucida Console", Courier, monospace;
      margin-bottom: 0;
    }
   
   
    footer {
      background-color: #f2f2f2;
      padding: 25px;
    }
  </style>
</head>

<body>
<div class="jumbotron">
  <div class="container text-Left">
    <h3>  CRAFTS HOUSE  </h3>
    <p> - เรินผ้าลีมาแล - </p>
  </div>
</div>

<!--แถบเมนู-->
<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li><a href="store.html"> หน้าแรก </a></li>
        <li class="dropdown">
          <a class="dropdown-toggle" data-toggle="dropdown" href="#">สินค้า
          <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="#"> เสื้อผ้า </a></li>
            <li><a href="#"> ผ้าชิ้น </a></li>
            <li><a href="#"> ผ้าทอ </a></li>
          </ul>
        </li>
        <li><a href="store-detail.html"> รายละเอียดสินค้า </a></li>
        <li><a href="payment.html"> แจ้งชำระเงิน </a></li>
        <li><a href="contact.html"> ติดต่อเรา </a></li>
        <li><a href="#"><span class="glyphicon glyphicon-search"></span> </a></li>
      </ul>
      <ul class="nav navbar-nav navbar-right">
        <li class="active"><a href="regis.php"><span class="glyphicon glyphicon-user"></span> บัญชีของคุณ </a></li>
        <li><a href="cart.html"><span class="glyphicon glyphicon-shopping-cart"></span> ตะกร้าสินค้า </a></li>
      </ul>
    </div>
  </div>
</nav>

<!--from ลงทะเบียน-->
    <div class="container">    
        <div id="loginbox" style="margin-top:50px;" class="mainbox col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-2">                    
            <div class="panel panel-info" >
                   <div class="panel-heading">
                   <center><div class="panel-title"> ลงทะเบียน </div></center>
                    </div>

                    <div style="padding-top:30px" class="panel-body" >

                        <div style="display:none" id="login-alert" class="alert alert-danger col-sm-12"></div>
                            
                        <form id="loginform" class="form-horizontal" role="form">
                                    
                            <div style="margin-bottom: 25px" class="input-group">
                                        <span class="input-group-addon"><i class="fa fa-users"></i></span>
                                        <input id="login-username" type="text" class="form-control" name="username" value="" placeholder="ชื่อผู้ใช้">                                        
                                    </div>
                                
                            <div style="margin-bottom: 25px" class="input-group">
                                        <span class="input-group-addon"><i class="fa fa-lock"></i></span>
                                        <input id="login-password" type="password" class="form-control" name="password" placeholder="รหัสผ่าน">
                                    </div>

                            <div style="margin-bottom: 25px" class="input-group">
                                        <span class="input-group-addon"><i class="fa fa-address-book-o"></i></span>
                                        <input id="login-name" type="text" class="form-control" name="name" placeholder="ชื่อ">
                                    </div>
                            
                            <div style="margin-bottom: 25px" class="input-group">
                                        <span class="input-group-addon"><i class="fa fa-address-card-o"></i></span>
                                        <input id="login-lastname" type="text" class="form-control" name="lastname" placeholder="นามสกุล">
                                    </div>  
                            
                            <div style="margin-bottom: 25px" class="input-group">
                                        <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                                        <input id="login-birthday" type="date" class="form-control" name="birthday" placeholder="ว/ด/ป เกิด">
                                    </div>  

                            <div style="margin-bottom: 25px" class="input-group">
                                        <span class="input-group-addon"><i class="fa fa-phone"></i></span>
                                        <input id="login-phone" type="text" class="form-control" name="phone" placeholder="เบอร์โทรศัพท์">
                                    </div>  
                                    
                            <div style="margin-bottom: 25px" class="input-group">
                                        <span class="input-group-addon"><i class="fa fa-send"></i></span>
                                        <input id="login-address" type="text" class="form-control" name="address" placeholder="ที่อยู่">
                                    </div>               

                            <div class="input-group">
                                      <div class="checkbox">
                                        <label>
                                          <input id="login-remember" type="checkbox" name="remember" value="1"> Remember me
                                        </label>
                                      </div>
                                    </div>

                                <div style="margin-top:10px" class="form-group">
                                    <!-- Button -->

                                    <div class="col-sm-12 controls">
                                    <center><a id="btn-login" href="#" class="btn btn-primary"> สมัครสมาชิก  </a>
                                    <a id="btn-login" href="fromlogin.html" class="btn btn-primary"> เข้าสู่ระบบ  </a>
                                    <a id="btn-fblogin" href="store.html" class="btn btn-primary"> ยกเลิก </a></center>

                                    </div>
                                </div>
                    </div>
                </div>    
            </form>     
        </div>                     
    </div>  
</body>
</html>