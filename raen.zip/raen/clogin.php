<?php

require_once 'db.php';

$mem_user =($_POST['mem_user']);
$mem_pass = ($_POST['mem_pass']);

$sql = "SELECT mem_id, mem_user, mem_pass, role FROM member
WHERE mem_user = ? AND mem_pass = ?";
$statement = $connection->prepare($sql);
$statement->execute([$mem_user, $mem_pass]);
$member = $statement->fetch(PDO::FETCH_OBJ);

session_start();
$_SESSION['mem_id'] = $member->mem_id;

echo $member->mem_user;
if($member){
    if($member->role=='admin'){
        header ("Location:store-details.html");
    }elseif($member->role=='sale'){
        header ("Location:pos.php");
    }
}else{
    header ("Location:home.html");
}
?>